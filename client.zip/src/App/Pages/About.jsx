// В файле AboutPage.js
import React from 'react';

function AboutPage() {
  return <h1>About Page</h1>;
}

export default AboutPage;