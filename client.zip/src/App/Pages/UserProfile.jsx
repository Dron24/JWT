import React from 'react';

function UserProfile() {
  return (
  <div>
    <h1>Профиль Пользователя</h1>
  </div>
  );
}

export default UserProfile;