// В файле HomePage.js
import React from 'react';

function HomePage() {
  return <h1>Home Page</h1>;
}

export default HomePage;